import { Component, } from '@angular/core';

@Component({
  selector: 'app-project1',
  templateUrl: './project1.component.html',
  styleUrls: ['./project1.component.css','./project1.component2.css'],
})
export class Project1Component {
  

}
